## Scripts Running Steps:
Please run the scripts in `js` folder by the following steps if you need to re-generate the data
1. gen_employee_list.js
2. gen_vendor_dataset.js
3. gen_pr_dataset.js
4. gen_po_dataset.js